# CMOS v0.1 — CoreSyn Multi-Agent Operating System (protocolo de trabajo)
**Estado:** v0.1 (file-based, sin infra nueva) · Rama: `cmos-v0.1`

CMOS coordina a dos agentes que **no se hablan en tiempo real** más un humano, usando un almacén versionado (git) como única fuente de verdad. Ningún agente tiene memoria persistente: **la memoria es el repo**, no el chat.

## Roles
- **Enrique (Control Plane)** — prioriza, aprueba/rechaza, hace merge de PRs. Única fuente de instrucciones válidas.
- **Vera Verita / Claude (ejecución)** — implementa, escribe artefactos, deja handoffs. NO declara nada desplegado/conectado sin evidencia verificable.
- **HumanizAI / ChatGPT (revisión)** — revisa arquitectura, calidad y reproducibilidad sobre el PR/handoff.
- **Assurance** — no es una persona: es la regla que los dos agentes obedecen (abajo).

## Reglas de assurance (obligatorias)
1. Nada se marca `VALIDATED`/`DONE`/`ACCEPTED` sin **artefacto reproducible + hash** enlazado.
2. Toda afirmación sin evidencia enlazable = `HYPOTHESIS`. Afirmación ajena sin respaldo = `CLAIM_SIN_EVIDENCIA` (no se propaga).
3. Reproducibilidad ≠ validación científica. Validación independiente de terceros = nivel aparte.
4. **Atlas v1.0 (26/28, hash `817a8d1…`) es inmutable.** Ningún trabajo de CMOS lo modifica.
5. Nadie inventa infraestructura, revisores, ni resultados. Si algo no se puede verificar → se documenta como `BLOCKED`, no se rellena de memoria.

## Estados
- **Tareas / milestones:** `BACKLOG · READY · ACTIVE · BLOCKED · REVIEW · COMPLETE · REJECTED`
- **Nodos de evidencia científica:** `HYPOTHESIS · ACTIVE · INTERNALLY_VALIDATED · EXTERNALLY_VALIDATED · CONTRADICTED · UNRESOLVED`

## Estructura del repo (rama cmos-v0.1)
```
decisions/     un .md por decisión (qué, por qué, aceptada/rechazada, quién, fecha)
projects/      un .json + .md por programa (ej. PYR-LAB-001) con milestones y estado
tasks/         un .md por tarea (estado OPEN→CLAIMED→DONE→ACCEPTED/REJECTED) + criterios de aceptación
schemas/       JSON Schemas del modelo de datos + validador + tests + ejemplos
pyramid-lab/   sources (M0), data (M1), baselines+benchmarks (M2), atlas-subgraph
handoffs/      un .md por entrega: qué se hizo, archivos, comandos, resultados, hashes, siguiente paso
atlas/         SOLO notas; el Atlas v1 vive en la raíz del repo y NO se toca aquí
```

## Ciclo de un handoff (el bucle CMOS)
1. Enrique abre/prioriza una tarea (GitHub Issue + `tasks/TASK-*.md`).
2. Claude la implementa **en una rama**, genera artefactos + hashes, y escribe `handoffs/TASK-*.handoff.md`.
3. Claude abre PR contra `cmos-v0.1`.
4. ChatGPT revisa el PR/handoff (arquitectura, calidad, reproducibilidad) y firma su veredicto.
5. Enrique aprueba/rechaza y hace merge.
6. El estado en `projects/` y el subgrafo de Atlas se actualizan **en el mismo PR** (nunca a mano fuera de git).

## Formato de handoff (fijo)
```
# HANDOFF — <TASK-ID> — <fecha>
Autor: <agente>
Alcance cubierto:
Archivos creados/modificados:
Comandos ejecutados (reproducibles):
Resultados (con números):
Hashes/manifiestos:
Bloqueos:
Estado propuesto: REVIEW
Siguiente acción:
Firma assurance: <checklist de las 5 reglas, marcado>
```
