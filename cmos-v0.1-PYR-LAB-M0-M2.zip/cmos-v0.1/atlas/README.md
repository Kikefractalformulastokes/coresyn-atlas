Este directorio es solo para notas de CMOS.
El Atlas v1 (26/28, hash 817a8d1...) vive en la RAÍZ del repo coresyn-atlas y NO se modifica desde aquí.
