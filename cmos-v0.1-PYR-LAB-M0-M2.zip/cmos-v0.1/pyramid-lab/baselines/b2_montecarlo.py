#!/usr/bin/env python3
"""B2 — Monte Carlo uncertainty propagation (transparent baseline).

Perturb each measured side by a Gaussian with its stated uncertainty (fixed seed),
recompute the B1 closure error each draw, and report the distribution + coverage.
Deterministic given the seed -> reproducible.
"""
import json, math, os, random, statistics

from b1_reconstruction import load_sides, reconstruct  # same dir

def run(n=10000, seed=42, dataset_path=None):
    sides, unc = load_sides(dataset_path)
    rng = random.Random(seed)
    closures = []
    means = []
    for _ in range(n):
        draw = {k: rng.gauss(sides[k], unc.get(k, 0.0)) for k in sides}
        r = reconstruct(draw)
        closures.append(r["closure_error_m"])
        means.append(r["mean_side_m"])
    closures.sort()
    def pct(p):
        i = min(len(closures) - 1, int(p * len(closures)))
        return round(closures[i], 5)
    return {
        "method": "B2-montecarlo-uncertainty",
        "n_draws": n,
        "seed": seed,
        "closure_error_m": {
            "mean": round(statistics.fmean(closures), 5),
            "stddev": round(statistics.pstdev(closures), 5),
            "p05": pct(0.05),
            "p50": pct(0.50),
            "p95": pct(0.95),
        },
        "mean_side_m": {
            "mean": round(statistics.fmean(means), 5),
            "stddev": round(statistics.pstdev(means), 5),
        },
    }

if __name__ == "__main__":
    print(json.dumps(run(), indent=2, ensure_ascii=False))
