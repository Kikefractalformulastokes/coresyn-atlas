#!/usr/bin/env python3
"""Tests for B1/B2. Run: python3 -m pytest pyramid-lab/baselines/test_baselines.py -q"""
import math
from b1_reconstruction import reconstruct
from b2_montecarlo import run

def test_perfect_square_has_zero_closure():
    r = reconstruct({"N": 230.0, "E": 230.0, "S": 230.0, "W": 230.0})
    assert r["closure_error_m"] == 0.0
    assert r["rmse_vs_nominal_m"] == 0.0

def test_unequal_sides_have_positive_closure():
    r = reconstruct({"N": 230.253, "E": 230.391, "S": 230.454, "W": 230.357})
    assert r["closure_error_m"] > 0.0

def test_closure_matches_hand_calc():
    # N-S=-0.201, W-E=-0.034 -> hypot
    r = reconstruct({"N": 230.253, "E": 230.391, "S": 230.454, "W": 230.357})
    expected = math.hypot(230.253 - 230.454, 230.357 - 230.391)
    assert abs(r["closure_error_m"] - round(expected, 5)) < 1e-6

def test_montecarlo_deterministic_with_seed():
    a = run(n=2000, seed=42)
    b = run(n=2000, seed=42)
    assert a == b  # same seed -> identical result (reproducible)

def test_montecarlo_seed_changes_result():
    a = run(n=2000, seed=42)
    b = run(n=2000, seed=7)
    assert a["closure_error_m"]["mean"] != b["closure_error_m"]["mean"]
