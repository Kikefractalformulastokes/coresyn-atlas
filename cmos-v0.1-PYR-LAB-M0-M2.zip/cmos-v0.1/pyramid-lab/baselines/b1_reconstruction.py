#!/usr/bin/env python3
"""B1 — Deterministic geometry reconstruction (transparent baseline).

Given the four measured base side lengths, reconstruct the base polygon under the
ideal assumption of right-angle corners, and compute transparent geometry metrics:
 - mean side, per-side deviation from mean
 - RMSE and max residual vs a nominal side
 - closure_error_m: the gap when walking N->E->S->W with exact 90-degree turns
   (0 for a perfect square; grows with side-length inequality)

No hidden parameters. No fitting. Fully determined by the inputs.
"""
import json, math, os

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def load_sides(dataset_path=None):
    dataset_path = dataset_path or os.path.join(ROOT, "pyramid-lab/data/geometry.dataset.v1.json")
    data = json.load(open(dataset_path, encoding="utf-8"))
    wanted = {
        "great_pyramid.base.north_side": "N",
        "great_pyramid.base.east_side": "E",
        "great_pyramid.base.south_side": "S",
        "great_pyramid.base.west_side": "W",
    }
    sides = {}
    unc = {}
    for m in data["measurements"]:
        if m["entity"] in wanted and m["unit"] == "m":
            sides[wanted[m["entity"]]] = m["value"]
            unc[wanted[m["entity"]]] = m.get("uncertainty_value") or 0.0
    return sides, unc

def reconstruct(sides, nominal=None):
    N, E, S, W = sides["N"], sides["E"], sides["S"], sides["W"]
    mean = (N + E + S + W) / 4.0
    nominal = nominal if nominal is not None else mean
    # walk with exact right-angle turns: start (0,0)
    # N side east-bound, E side south-bound, S side west-bound, W side north-bound
    x, y = 0.0, 0.0
    x += N            # go east N
    y -= E            # go south E
    x -= S            # go west S
    y += W            # go north W
    closure_error = math.hypot(x, y)   # distance from start (0 = perfect square)
    residuals = [sides[k] - nominal for k in ("N", "E", "S", "W")]
    rmse = math.sqrt(sum(r * r for r in residuals) / 4.0)
    max_res = max(abs(r) for r in residuals)
    dev_from_mean = {k: round(sides[k] - mean, 4) for k in ("N", "E", "S", "W")}
    return {
        "method": "B1-deterministic-reconstruction",
        "inputs_m": {k: sides[k] for k in ("N", "E", "S", "W")},
        "nominal_side_m": round(nominal, 4),
        "mean_side_m": round(mean, 4),
        "deviation_from_mean_m": dev_from_mean,
        "rmse_vs_nominal_m": round(rmse, 5),
        "max_residual_m": round(max_res, 5),
        "closure_error_m": round(closure_error, 5),
        "hard_constraint_violations": 0,
    }

if __name__ == "__main__":
    sides, _ = load_sides()
    print(json.dumps(reconstruct(sides), indent=2, ensure_ascii=False))
