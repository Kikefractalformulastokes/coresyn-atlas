#!/usr/bin/env python3
"""M2 benchmark runner. Runs B1 + B2, writes results, seals a SHA-256 manifest
over inputs + outputs so the run is verifiable and reproducible by command.

Run from repo root:  python3 pyramid-lab/benchmarks/run_benchmark.py
"""
import json, os, sys, hashlib

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(ROOT, "pyramid-lab/baselines"))

from b1_reconstruction import load_sides, reconstruct
from b2_montecarlo import run as run_mc

OUTDIR = os.path.join(ROOT, "pyramid-lab/benchmarks/results")

def sha256_file(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()

def main():
    os.makedirs(OUTDIR, exist_ok=True)
    sides, unc = load_sides()
    b1 = reconstruct(sides)
    b2 = run_mc(n=10000, seed=42)

    b1_path = os.path.join(OUTDIR, "b1_result.json")
    b2_path = os.path.join(OUTDIR, "b2_result.json")
    json.dump(b1, open(b1_path, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(b2, open(b2_path, "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    dataset_path = os.path.join(ROOT, "pyramid-lab/data/geometry.dataset.v1.json")
    manifest = {
        "benchmark": "PYR-M2-baselines",
        "dataset_version": "geometry.dataset.v1",
        "inputs": {"geometry.dataset.v1.json": sha256_file(dataset_path)},
        "outputs": {"b1_result.json": sha256_file(b1_path), "b2_result.json": sha256_file(b2_path)},
        "methods": ["B1-deterministic-reconstruction", "B2-montecarlo-uncertainty(seed=42,n=10000)"],
        "reproduce": "python3 pyramid-lab/benchmarks/run_benchmark.py",
        "note": "Reproducibility only. No hypothesis is confirmed by this run; it characterizes base-geometry consistency and uncertainty.",
    }
    man_path = os.path.join(OUTDIR, "manifest.json")
    json.dump(manifest, open(man_path, "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({"b1": b1, "b2": b2, "manifest": manifest}, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
