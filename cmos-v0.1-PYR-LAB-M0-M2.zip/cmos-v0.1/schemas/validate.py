#!/usr/bin/env python3
"""CMOS v0.1 — validate all Pyramid Lab data files against JSON Schemas.
Usage: python3 schemas/validate.py   (run from repo root)
Exit code 0 = all valid; 1 = at least one failure.
"""
import json, sys, glob, os

try:
    from jsonschema import Draft7Validator
except ImportError:
    print("jsonschema not installed: pip install jsonschema --break-system-packages")
    sys.exit(2)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def load(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)

SCHEMAS = {
    "source": load(os.path.join(ROOT, "schemas/source.schema.json")),
    "measurement": load(os.path.join(ROOT, "schemas/measurement.schema.json")),
    "hypothesis": load(os.path.join(ROOT, "schemas/hypothesis.schema.json")),
    "experiment": load(os.path.join(ROOT, "schemas/experiment.schema.json")),
}

# (glob pattern, schema key, is the file a list of records or a wrapped registry?)
TARGETS = [
    ("schemas/examples/source.example.json", "source", "single"),
    ("schemas/examples/measurement.example.json", "measurement", "single"),
    ("schemas/examples/hypothesis.example.json", "hypothesis", "single"),
    ("schemas/examples/experiment.example.json", "experiment", "single"),
    ("pyramid-lab/sources/sources.json", "source", "registry:sources"),
    ("pyramid-lab/data/geometry.dataset.v1.json", "measurement", "registry:measurements"),
    ("pyramid-lab/atlas-subgraph/pyramid-subgraph.json", "hypothesis", "registry:hypotheses"),
]

def records_for(path, kind):
    data = load(path)
    if kind == "single":
        return [data]
    key = kind.split(":", 1)[1]
    return data.get(key, [])

def main():
    errors = 0
    checked = 0
    for rel, skey, kind in TARGETS:
        path = os.path.join(ROOT, rel)
        if not os.path.exists(path):
            print(f"SKIP  {rel} (not found)")
            continue
        validator = Draft7Validator(SCHEMAS[skey])
        for i, rec in enumerate(records_for(path, kind)):
            checked += 1
            errs = sorted(validator.iter_errors(rec), key=lambda e: e.path)
            if errs:
                errors += 1
                loc = rec.get("source_id") or rec.get("measurement_id") or rec.get("hypothesis_id") or f"index {i}"
                print(f"FAIL  {rel} [{loc}] ({skey})")
                for e in errs:
                    print(f"        - {list(e.path)}: {e.message}")
            else:
                loc = rec.get("source_id") or rec.get("measurement_id") or rec.get("hypothesis_id") or f"index {i}"
                print(f"OK    {rel} [{loc}] ({skey})")
    print(f"\n{checked} records checked · {errors} invalid")
    sys.exit(1 if errors else 0)

if __name__ == "__main__":
    main()
