#!/usr/bin/env python3
"""Tests: every example validates; a deliberately-bad record fails.
Run: python3 -m pytest schemas/test_schemas.py -q   (from repo root)
"""
import json, os, copy
from jsonschema import Draft7Validator

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def load(rel):
    with open(os.path.join(ROOT, rel), encoding="utf-8") as f:
        return json.load(f)

SRC = load("schemas/source.schema.json")
MEAS = load("schemas/measurement.schema.json")
HYP = load("schemas/hypothesis.schema.json")
EXP = load("schemas/experiment.schema.json")

def valid(schema, rec):
    return not list(Draft7Validator(schema).iter_errors(rec))

def test_examples_valid():
    assert valid(SRC, load("schemas/examples/source.example.json"))
    assert valid(MEAS, load("schemas/examples/measurement.example.json"))
    assert valid(HYP, load("schemas/examples/hypothesis.example.json"))
    assert valid(EXP, load("schemas/examples/experiment.example.json"))

def test_bad_source_rejected():
    bad = copy.deepcopy(load("schemas/examples/source.example.json"))
    bad["evidence_level"] = "E9"          # not in enum
    assert not valid(SRC, bad)

def test_bad_measurement_rejected():
    bad = copy.deepcopy(load("schemas/examples/measurement.example.json"))
    bad["confidence"] = 5                  # > 1
    assert not valid(MEAS, bad)

def test_measurement_requires_source():
    bad = copy.deepcopy(load("schemas/examples/measurement.example.json"))
    del bad["source_id"]                   # required
    assert not valid(MEAS, bad)

def test_registries_validate():
    for rec in load("pyramid-lab/sources/sources.json")["sources"]:
        assert valid(SRC, rec), rec.get("source_id")
    for rec in load("pyramid-lab/data/geometry.dataset.v1.json")["measurements"]:
        assert valid(MEAS, rec), rec.get("measurement_id")
    for rec in load("pyramid-lab/atlas-subgraph/pyramid-subgraph.json")["hypotheses"]:
        assert valid(HYP, rec), rec.get("hypothesis_id")
