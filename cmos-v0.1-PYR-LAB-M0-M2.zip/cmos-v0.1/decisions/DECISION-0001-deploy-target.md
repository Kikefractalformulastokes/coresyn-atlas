# DECISION-0001 — Deploy target de Pyramid Lab
**Fecha:** 2026-07-27 · **Decisor:** Enrique · **Estado:** ACEPTADA (A(c) + B)

## Contexto
coresyn.io es un sitio estático en Cloudflare Pages (verificado 2026-07-27). No hay acceso desde esta sesión al repo/proyecto que lo construye.

## Opciones
- (a) Conectar el repo de coresyn.io → deploy nativo en el dominio. *Bloqueada hoy: falta acceso.*
- (b) Subdominio nuevo `pyramid.coresyn.io` (Cloudflare Pages project nuevo).
- (c) Construir en el repo `coresyn-atlas` (GitHub Pages) como `/pyramid-lab/`, migrable a coresyn.io cuando (a) sea posible.

## Decisión
**A(c) + B.** Construir primero en `coresyn-atlas`, rama `cmos-v0.1`. Snapshot Atlas v1 intacto. Módulo diseñado para migrar a coresyn.io cuando haya acceso verificado. No se afirma despliegue/integración hasta poder verificarse.

## Consecuencias
- Cero bloqueo para M0–M2 y el modelo de datos.
- M8 (public launch) queda BLOCKED hasta resolver (a): acceso al repo/Cloudflare Pages de coresyn.io.
- No se toca DNS ni deploy de coresyn.io sin propietario + proveedor + rollback confirmados.
