# TASK-PYR-0001 — Pyramid Lab M0–M2 + CMOS handoff
**GitHub Issue:** #1 · **Rama:** `cmos-v0.1` · **Estado:** DONE → REVIEW

## Alcance
M0 (registro de fuentes) · M1 (dataset geométrico sourced) · M2 (baselines B1/B2 + benchmark reproducible) · CMOS v0.1 protocolo · esquemas JSON + validador + tests · programa CEOS PYR-LAB-001 · subgrafo Pyramid en Atlas (separado de v1).

## Reglas científicas aplicadas
- Cero evidencia validada; toda hipótesis = HYPOTHESIS.
- Cada medida enlaza a un source_id; figuras sin confirmar = PENDING_VERIFICATION.
- Reproducibilidad != validación. Baselines miden consistencia/incertidumbre, no confirman hipótesis.
- Atlas v1 (26/28, hash 817a8d1…) intacto.

## Entregables (estado REVIEW, pendientes de PR + revisión ChatGPT + merge Enrique)
- `PROTOCOL.md`, `schemas/*` (+ validador + tests), `pyramid-lab/sources/sources.json`,
  `pyramid-lab/data/geometry.dataset.v1.json`, `pyramid-lab/baselines/*` (+ tests),
  `pyramid-lab/benchmarks/*` (+ results + manifest), `pyramid-lab/atlas-subgraph/pyramid-subgraph.json`,
  `projects/PYR-LAB-001.json`, `decisions/DECISION-0001-deploy-target.md`, `handoffs/TASK-PYR-0001.handoff.md`.

## Criterios de aceptación (verificados)
- [x] Esquemas validan (22/22 registros, 0 inválidos)
- [x] Tests verdes (10/10: 5 schema + 5 baselines)
- [x] Benchmark reproducible (hashes de salida idénticos al re-ejecutar)
- [x] Manifiesto SHA-256 sellado sobre inputs+outputs
- [x] >=5 fuentes reales con evidence_level
- [x] Atlas v1 no modificado
- [ ] PR revisado por ChatGPT (assurance)
- [ ] Merge aprobado por Enrique
